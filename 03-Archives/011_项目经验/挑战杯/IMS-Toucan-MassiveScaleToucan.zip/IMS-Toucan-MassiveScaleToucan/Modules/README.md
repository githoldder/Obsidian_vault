This directory contains all the models that are used in this toolkit for various tasks. The models' directories contain
their
feature extractors, their datasets, their architectures, and their train loops. 